import { useEffect, useState } from "react";
import { Flame, Clock, Target, Trophy, ChevronRight } from "lucide-react";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import * as Icones from "lucide-react";

export default function Painel() {
  const { perfil, usuario } = useAuth();
  const [materias, setMaterias] = useState([]);
  const [metas, setMetas] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    async function carregar() {
      const [{ data: mats }, { data: mts }] = await Promise.all([
        supabase.from("materias").select("*").order("ordem"),
        supabase.from("metas").select("*").eq("user_id", usuario.id).limit(3),
      ]);
      setMaterias(mats ?? []);
      setMetas(mts ?? []);
      setCarregando(false);
    }
    if (usuario) carregar();
  }, [usuario]);

  const xpProximoNivel = (perfil?.nivel ?? 1) * 500;
  const progressoNivel = perfil ? Math.min(100, (perfil.xp / xpProximoNivel) * 100) : 0;

  return (
    <div className="min-h-screen bg-base-claro dark:bg-base-escuro">
      <Navbar />
      <main className="max-w-6xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-display font-semibold mb-1">
          Olá, {perfil?.nome?.split(" ")[0] ?? "estudante"} 👋
        </h1>
        <p className="text-slate-500 mb-8">Vamos continuar de onde você parou.</p>

        {/* Cartões de estatística */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <CartaoStat icone={Flame} label="Sequência" valor="0 dias" cor="from-orange-400 to-red-500" />
          <CartaoStat icone={Clock} label="Horas estudadas" valor={`${perfil?.horas_estudadas ?? 0}h`} cor="from-blue-400 to-cyan-500" />
          <CartaoStat icone={Target} label="Metas ativas" valor={metas.length} cor="from-emerald-400 to-teal-500" />
          <CartaoStat icone={Trophy} label="Nível" valor={perfil?.nivel ?? 1} cor="from-roxo to-azul" />
        </div>

        {/* Barra de XP */}
        <div className="vidro rounded-2xl p-5 mb-8">
          <div className="flex justify-between text-sm mb-2">
            <span className="font-medium">Nível {perfil?.nivel ?? 1}</span>
            <span className="text-slate-500">{perfil?.xp ?? 0} / {xpProximoNivel} XP</span>
          </div>
          <div className="h-3 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
            <div
              className="h-full bg-gradiente-neon rounded-full transition-all duration-700"
              style={{ width: `${progressoNivel}%` }}
            />
          </div>
        </div>

        {/* Matérias */}
        <h2 className="text-lg font-display font-semibold mb-4">Matérias</h2>
        {carregando ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-28 rounded-2xl bg-slate-200/50 dark:bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {materias.map((m) => {
              const Icone = Icones[m.icone] || Icones.BookOpen;
              return (
                <button
                  key={m.id}
                  className="vidro rounded-2xl p-5 text-left hover:-translate-y-1 hover:shadow-lg transition-all duration-300 group"
                >
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                    style={{ backgroundColor: `${m.cor}22` }}
                  >
                    <Icone size={20} style={{ color: m.cor }} />
                  </div>
                  <p className="font-medium text-sm">{m.nome}</p>
                  <span className="text-xs text-slate-400 flex items-center gap-0.5 mt-1 group-hover:text-roxo transition-colors">
                    Estudar <ChevronRight size={12} />
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

function CartaoStat({ icone: Icone, label, valor, cor }) {
  return (
    <div className="vidro rounded-2xl p-4">
      <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${cor} flex items-center justify-center mb-3`}>
        <Icone size={16} className="text-white" />
      </div>
      <p className="text-xl font-display font-semibold">{valor}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </div>
  );
}
