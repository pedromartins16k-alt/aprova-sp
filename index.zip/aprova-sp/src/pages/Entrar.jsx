import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, ArrowRight, GraduationCap } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Entrar() {
  const { entrar } = useAuth();
  const navegar = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setErro("");
    setCarregando(true);
    const { error } = await entrar({ email, senha });
    setCarregando(false);
    if (error) {
      setErro(
        error.message.includes("Invalid login")
          ? "E-mail ou senha incorretos."
          : "Não foi possível entrar. Tente novamente."
      );
      return;
    }
    navegar("/painel");
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradiente-principal p-6">
      <div className="w-full max-w-sm vidro rounded-2xl p-8">
        <div className="flex items-center gap-2 mb-8 justify-center">
          <div className="w-9 h-9 rounded-lg bg-gradiente-neon flex items-center justify-center">
            <GraduationCap size={18} className="text-white" />
          </div>
          <span className="font-display font-bold text-xl">
            Aprova<span className="text-roxo">SP</span>
          </span>
        </div>

        <h1 className="text-2xl font-display font-semibold mb-1 text-center">Bem-vindo de volta</h1>
        <p className="text-sm text-slate-500 text-center mb-6">Entre para continuar seus estudos.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Campo icon={Mail} type="email" placeholder="seu@email.com" value={email} onChange={setEmail} required />
          <Campo icon={Lock} type="password" placeholder="Senha" value={senha} onChange={setSenha} required />

          {erro && <p className="text-sm text-red-500">{erro}</p>}

          <button
            disabled={carregando}
            className="w-full bg-gradiente-principal text-white rounded-xl py-3 font-medium flex items-center justify-center gap-2 hover:brightness-110 transition disabled:opacity-60"
          >
            {carregando ? "Entrando..." : "Entrar"} <ArrowRight size={16} />
          </button>
        </form>

        <div className="flex justify-between mt-4 text-sm">
          <Link to="/recuperar-senha" className="text-roxo hover:underline">
            Esqueci minha senha
          </Link>
          <Link to="/cadastro" className="text-roxo hover:underline">
            Criar conta
          </Link>
        </div>
      </div>
    </div>
  );
}

export function Campo({ icon: Icone, onChange, value, ...props }) {
  return (
    <div className="flex items-center gap-2 border border-slate-200 dark:border-white/10 rounded-xl px-3.5 py-2.5 bg-white/70 dark:bg-white/5 focus-within:ring-2 focus-within:ring-roxo">
      <Icone size={16} className="text-slate-400 shrink-0" />
      <input
        {...props}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full outline-none bg-transparent text-sm"
      />
    </div>
  );
}
