import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Navbar from "../components/Navbar";
import { BookOpen, ExternalLink } from "lucide-react";

export default function Resumos() {
  const [resumos, setResumos] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    supabase
      .from("resumos")
      .select("id, titulo, conteudo, fonte, atualizado_em, topicos(nome, materias(nome, cor))")
      .order("atualizado_em", { ascending: false })
      .then(({ data }) => {
        setResumos(data ?? []);
        setCarregando(false);
      });
  }, []);

  return (
    <div className="min-h-screen bg-base-claro dark:bg-base-escuro">
      <Navbar />
      <main className="max-w-4xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-display font-semibold mb-1">Resumos</h1>
        <p className="text-slate-500 mb-6">Atualizados automaticamente a partir de fontes oficiais.</p>

        {carregando && (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-20 rounded-2xl bg-slate-200/50 dark:bg-white/5 animate-pulse" />
            ))}
          </div>
        )}

        {!carregando && resumos.length === 0 && (
          <div className="vidro rounded-2xl p-10 text-center">
            <BookOpen className="mx-auto mb-3 text-slate-400" />
            <p className="text-slate-500">
              Nenhum resumo cadastrado ainda. Assim que a automação de conteúdo rodar, eles
              aparecem aqui automaticamente — sem precisar mexer no código.
            </p>
          </div>
        )}

        <div className="space-y-3">
          {resumos.map((r) => (
            <div key={r.id} className="vidro rounded-2xl p-5 hover:-translate-y-0.5 transition-transform">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-medium">{r.titulo}</h3>
                {r.fonte && (
                  <span className="text-xs flex items-center gap-1 text-slate-400">
                    <ExternalLink size={12} /> {r.fonte}
                  </span>
                )}
              </div>
              <p className="text-sm text-slate-500 line-clamp-2">{r.conteudo}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
