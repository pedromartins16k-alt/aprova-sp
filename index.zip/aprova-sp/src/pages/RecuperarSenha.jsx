import { useState } from "react";
import { Link } from "react-router-dom";
import { Mail, ArrowRight, CheckCircle2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { Campo } from "./Entrar";

export default function RecuperarSenha() {
  const { recuperarSenha } = useAuth();
  const [email, setEmail] = useState("");
  const [enviado, setEnviado] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    await recuperarSenha(email);
    setEnviado(true);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradiente-principal p-6">
      <div className="w-full max-w-sm vidro rounded-2xl p-8">
        {!enviado ? (
          <>
            <h1 className="text-2xl font-display font-semibold mb-1 text-center">Recuperar senha</h1>
            <p className="text-sm text-slate-500 text-center mb-6">
              Informe seu e-mail para receber o link de redefinição.
            </p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Campo icon={Mail} type="email" placeholder="seu@email.com" value={email} onChange={setEmail} required />
              <button className="w-full bg-gradiente-principal text-white rounded-xl py-3 font-medium flex items-center justify-center gap-2 hover:brightness-110 transition">
                Enviar link <ArrowRight size={16} />
              </button>
            </form>
          </>
        ) : (
          <div className="text-center py-6">
            <CheckCircle2 size={40} className="text-emerald-500 mx-auto mb-4" />
            <p className="text-sm text-slate-500">
              Se este e-mail estiver cadastrado, você receberá um link para redefinir sua senha.
            </p>
          </div>
        )}
        <p className="text-sm text-center mt-4">
          <Link to="/entrar" className="text-roxo hover:underline">
            Voltar para login
          </Link>
        </p>
      </div>
    </div>
  );
}
