import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Navbar from "../components/Navbar";
import { Layers } from "lucide-react";

export default function Flashcards() {
  const [cartas, setCartas] = useState([]);
  const [indice, setIndice] = useState(0);
  const [virado, setVirado] = useState(false);

  useEffect(() => {
    supabase.from("flashcards").select("*").then(({ data }) => setCartas(data ?? []));
  }, []);

  const atual = cartas[indice];

  function proximo() {
    setVirado(false);
    setIndice((i) => (i + 1) % Math.max(cartas.length, 1));
  }

  return (
    <div className="min-h-screen bg-base-claro dark:bg-base-escuro">
      <Navbar />
      <main className="max-w-xl mx-auto px-6 py-8 text-center">
        <h1 className="text-2xl font-display font-semibold mb-6">Flashcards</h1>

        {!atual ? (
          <div className="vidro rounded-2xl p-10">
            <Layers className="mx-auto mb-3 text-slate-400" />
            <p className="text-slate-500">Nenhum flashcard cadastrado ainda.</p>
          </div>
        ) : (
          <>
            <div
              onClick={() => setVirado((v) => !v)}
              className="vidro rounded-3xl p-12 min-h-[220px] flex items-center justify-center cursor-pointer select-none hover:shadow-xl transition-shadow"
            >
              <p className="text-lg font-medium">{virado ? atual.verso : atual.frente}</p>
            </div>
            <p className="text-xs text-slate-400 mt-3">Toque no card para virar</p>
            <button
              onClick={proximo}
              className="mt-6 bg-gradiente-principal text-white rounded-xl px-6 py-2.5 font-medium hover:brightness-110 transition"
            >
              Próximo card
            </button>
          </>
        )}
      </main>
    </div>
  );
}
