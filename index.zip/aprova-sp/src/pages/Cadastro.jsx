import { useState } from "react";
import { Link } from "react-router-dom";
import { User, Phone, Mail, Lock, ArrowRight, GraduationCap, CheckCircle2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { Campo } from "./Entrar";

export default function Cadastro() {
  const { cadastrar } = useAuth();
  const [form, setForm] = useState({ nome: "", telefone: "", email: "", senha: "" });
  const [erro, setErro] = useState("");
  const [enviado, setEnviado] = useState(false);
  const [carregando, setCarregando] = useState(false);

  const set = (campo) => (v) => setForm((f) => ({ ...f, [campo]: v }));

  async function handleSubmit(e) {
    e.preventDefault();
    setErro("");
    if (form.senha.length < 8) {
      setErro("A senha precisa ter no mínimo 8 caracteres.");
      return;
    }
    setCarregando(true);
    const { error } = await cadastrar(form);
    setCarregando(false);
    if (error) {
      setErro(
        error.message.includes("already registered")
          ? "Este e-mail já está cadastrado."
          : "Não foi possível criar a conta. Tente novamente."
      );
      return;
    }
    setEnviado(true);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradiente-principal p-6">
      <div className="w-full max-w-sm vidro rounded-2xl p-8">
        <div className="flex items-center gap-2 mb-8 justify-center">
          <div className="w-9 h-9 rounded-lg bg-gradiente-neon flex items-center justify-center">
            <GraduationCap size={18} className="text-white" />
          </div>
          <span className="font-display font-bold text-xl">
            Aprova<span className="text-roxo">SP</span>
          </span>
        </div>

        {!enviado ? (
          <>
            <h1 className="text-2xl font-display font-semibold mb-1 text-center">Criar conta</h1>
            <p className="text-sm text-slate-500 text-center mb-6">Leva menos de um minuto.</p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <Campo icon={User} placeholder="Nome completo" value={form.nome} onChange={set("nome")} required />
              <Campo icon={Phone} placeholder="(11) 9 9999-9999" value={form.telefone} onChange={set("telefone")} required />
              <Campo icon={Mail} type="email" placeholder="seu@email.com" value={form.email} onChange={set("email")} required />
              <Campo icon={Lock} type="password" placeholder="Criar senha (mín. 8 caracteres)" value={form.senha} onChange={set("senha")} required />

              {erro && <p className="text-sm text-red-500">{erro}</p>}

              <button
                disabled={carregando}
                className="w-full bg-gradiente-principal text-white rounded-xl py-3 font-medium flex items-center justify-center gap-2 hover:brightness-110 transition disabled:opacity-60"
              >
                {carregando ? "Criando..." : "Criar conta"} <ArrowRight size={16} />
              </button>
            </form>

            <p className="text-sm text-center mt-4">
              Já tem conta?{" "}
              <Link to="/entrar" className="text-roxo hover:underline">
                Entrar
              </Link>
            </p>
          </>
        ) : (
          <div className="text-center py-6">
            <div className="w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-500/10 flex items-center justify-center mx-auto mb-5">
              <CheckCircle2 size={28} className="text-emerald-500" />
            </div>
            <h2 className="text-xl font-display font-semibold mb-2">Quase lá!</h2>
            <p className="text-sm text-slate-500">
              Enviamos um link de confirmação para <b>{form.email}</b>. Abra seu e-mail e clique
              no link para ativar sua conta.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
