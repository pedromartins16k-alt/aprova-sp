import { Link } from "react-router-dom";
import { GraduationCap, ArrowRight, BookOpen, Trophy, Layers } from "lucide-react";
import AlternarTema from "../components/AlternarTema";

export default function Inicio() {
  return (
    <div className="min-h-screen bg-base-claro dark:bg-base-escuro overflow-hidden">
      <header className="flex items-center justify-between max-w-6xl mx-auto px-6 py-6">
        <div className="flex items-center gap-2 font-display font-bold text-lg">
          <div className="w-8 h-8 rounded-lg bg-gradiente-neon flex items-center justify-center">
            <GraduationCap size={18} className="text-white" />
          </div>
          Aprova<span className="text-roxo">SP</span>
        </div>
        <div className="flex items-center gap-3">
          <AlternarTema />
          <Link to="/entrar" className="text-sm font-medium hover:text-roxo transition-colors">
            Entrar
          </Link>
          <Link
            to="/cadastro"
            className="bg-gradiente-principal text-white text-sm font-medium px-4 py-2 rounded-xl hover:brightness-110 transition"
          >
            Criar conta
          </Link>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-16 md:py-24 text-center relative">
        <div className="absolute top-10 left-1/4 w-72 h-72 bg-roxo/20 rounded-full blur-3xl animar-flutuar" />
        <div className="absolute top-40 right-1/4 w-72 h-72 bg-neon/20 rounded-full blur-3xl animar-flutuar" style={{ animationDelay: "1s" }} />

        <h1 className="relative text-4xl md:text-6xl font-display font-extrabold leading-tight mb-6">
          Sua rota para a <span className="bg-gradiente-neon bg-clip-text text-transparent">aprovação</span>
        </h1>
        <p className="relative text-slate-500 max-w-xl mx-auto mb-8">
          Preparação completa para o ENEM e os vestibulares da Grande São Paulo — Unicamp,
          PUC-SP, USP, Mackenzie e mais. Resumos, questões comentadas, simulados e flashcards
          sempre atualizados.
        </p>
        <Link
          to="/cadastro"
          className="relative inline-flex items-center gap-2 bg-gradiente-principal text-white font-medium px-6 py-3 rounded-xl hover:brightness-110 transition shadow-lg"
        >
          Começar agora <ArrowRight size={16} />
        </Link>

        <div className="relative grid md:grid-cols-3 gap-5 mt-20 text-left">
          <Recurso icone={BookOpen} titulo="Resumos sempre atuais" texto="Conteúdo revisado e atualizado continuamente a partir de fontes oficiais." />
          <Recurso icone={Layers} titulo="Flashcards e simulados" texto="Pratique no formato real de cada vestibular, no seu ritmo." />
          <Recurso icone={Trophy} titulo="Gamificação" texto="Ganhe XP, suba de nível e acompanhe seu progresso em tempo real." />
        </div>
      </main>
    </div>
  );
}

function Recurso({ icone: Icone, titulo, texto }) {
  return (
    <div className="vidro rounded-2xl p-6 hover:-translate-y-1 transition-transform">
      <div className="w-10 h-10 rounded-xl bg-gradiente-neon flex items-center justify-center mb-4">
        <Icone size={18} className="text-white" />
      </div>
      <h3 className="font-display font-semibold mb-1">{titulo}</h3>
      <p className="text-sm text-slate-500">{texto}</p>
    </div>
  );
}
