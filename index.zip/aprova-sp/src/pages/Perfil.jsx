import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import { User, Phone, Mail, Award } from "lucide-react";

export default function Perfil() {
  const { perfil, usuario } = useAuth();

  return (
    <div className="min-h-screen bg-base-claro dark:bg-base-escuro">
      <Navbar />
      <main className="max-w-2xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-display font-semibold mb-6">Meu perfil</h1>

        <div className="vidro rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-gradiente-principal flex items-center justify-center text-white text-xl font-display font-semibold">
              {perfil?.nome?.[0]?.toUpperCase() ?? "?"}
            </div>
            <div>
              <p className="font-display font-semibold text-lg">{perfil?.nome}</p>
              <span className="text-xs px-2 py-0.5 rounded-full bg-gradiente-neon text-white">
                Nível {perfil?.nivel ?? 1}
              </span>
            </div>
          </div>

          <div className="space-y-3 text-sm">
            <Info icone={Mail} valor={usuario?.email} />
            <Info icone={Phone} valor={perfil?.telefone} />
            <Info icone={Award} valor={`${perfil?.xp ?? 0} XP acumulados`} />
          </div>
        </div>
      </main>
    </div>
  );
}

function Info({ icone: Icone, valor }) {
  return (
    <div className="flex items-center gap-3 text-slate-600 dark:text-slate-300">
      <Icone size={16} className="text-roxo" />
      <span>{valor || "—"}</span>
    </div>
  );
}
