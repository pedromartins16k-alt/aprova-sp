import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Navbar from "../components/Navbar";
import { ClipboardList, Clock, ChevronRight } from "lucide-react";

export default function Simulados() {
  const [simulados, setSimulados] = useState([]);

  useEffect(() => {
    supabase.from("simulados").select("*").order("criado_em", { ascending: false }).then(({ data }) => {
      setSimulados(data ?? []);
    });
  }, []);

  return (
    <div className="min-h-screen bg-base-claro dark:bg-base-escuro">
      <Navbar />
      <main className="max-w-4xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-display font-semibold mb-1">Simulados</h1>
        <p className="text-slate-500 mb-6">Pratique no formato real dos vestibulares.</p>

        {simulados.length === 0 ? (
          <div className="vidro rounded-2xl p-10 text-center">
            <ClipboardList className="mx-auto mb-3 text-slate-400" />
            <p className="text-slate-500">Nenhum simulado publicado ainda.</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {simulados.map((s) => (
              <button
                key={s.id}
                className="vidro rounded-2xl p-5 flex items-center justify-between hover:-translate-y-0.5 transition-transform text-left"
              >
                <div>
                  <p className="font-medium">{s.titulo}</p>
                  <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                    <Clock size={12} /> {s.duracao_min} min · {s.vestibular}
                  </p>
                </div>
                <ChevronRight size={18} className="text-slate-400" />
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
