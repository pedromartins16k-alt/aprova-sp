import { Sun, Moon } from "lucide-react";
import { useTheme } from "../context/ThemeContext";

export default function AlternarTema() {
  const { escuro, alternar } = useTheme();
  return (
    <button
      onClick={alternar}
      aria-label="Alternar tema claro/escuro"
      className="w-10 h-10 rounded-full vidro flex items-center justify-center hover:scale-105 transition-transform"
    >
      {escuro ? <Sun size={18} className="text-neon" /> : <Moon size={18} className="text-roxo" />}
    </button>
  );
}
