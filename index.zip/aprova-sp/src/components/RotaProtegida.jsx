import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function RotaProtegida({ children }) {
  const { usuario, carregando } = useAuth();

  if (carregando) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-base-claro dark:bg-base-escuro">
        <div className="w-10 h-10 border-4 border-roxo/30 border-t-roxo rounded-full animate-spin" />
      </div>
    );
  }

  if (!usuario) return <Navigate to="/entrar" replace />;
  return children;
}
