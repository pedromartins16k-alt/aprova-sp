import { NavLink, useNavigate } from "react-router-dom";
import { LayoutDashboard, BookOpen, Layers, ClipboardList, User, LogOut, GraduationCap } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import AlternarTema from "./AlternarTema";

const links = [
  { to: "/painel", label: "Painel", icone: LayoutDashboard },
  { to: "/resumos", label: "Resumos", icone: BookOpen },
  { to: "/flashcards", label: "Flashcards", icone: Layers },
  { to: "/simulados", label: "Simulados", icone: ClipboardList },
  { to: "/perfil", label: "Perfil", icone: User },
];

export default function Navbar() {
  const { sair, perfil } = useAuth();
  const navegar = useNavigate();

  async function handleSair() {
    await sair();
    navegar("/entrar");
  }

  return (
    <header className="sticky top-0 z-40 vidro border-b">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-2 font-display font-bold text-lg">
          <div className="w-8 h-8 rounded-lg bg-gradiente-neon flex items-center justify-center">
            <GraduationCap size={18} className="text-white" />
          </div>
          Aprova<span className="text-roxo">SP</span>
        </div>

        <nav className="hidden md:flex items-center gap-1">
          {links.map(({ to, label, icone: Icone }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-gradiente-principal text-white shadow-md"
                    : "text-slate-600 dark:text-slate-300 hover:bg-roxo/10"
                }`
              }
            >
              <Icone size={16} /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {perfil && (
            <span className="hidden sm:flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-gradiente-neon text-white">
              Nível {perfil.nivel} · {perfil.xp} XP
            </span>
          )}
          <AlternarTema />
          <button
            onClick={handleSair}
            aria-label="Sair"
            className="w-10 h-10 rounded-full vidro flex items-center justify-center hover:text-red-500 transition-colors"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </header>
  );
}
