import { createContext, useContext, useEffect, useState } from "react";

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [escuro, setEscuro] = useState(() => {
    const salvo = localStorage.getItem("aprovasp-tema");
    if (salvo) return salvo === "escuro";
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", escuro);
    localStorage.setItem("aprovasp-tema", escuro ? "escuro" : "claro");
  }, [escuro]);

  return (
    <ThemeContext.Provider value={{ escuro, alternar: () => setEscuro((v) => !v) }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
