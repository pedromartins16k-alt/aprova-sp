import { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [perfil, setPerfil] = useState(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUsuario(session?.user ?? null);
      setCarregando(false);
    });

    const { data: assinatura } = supabase.auth.onAuthStateChange((_evento, session) => {
      setUsuario(session?.user ?? null);
    });

    return () => assinatura.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!usuario) {
      setPerfil(null);
      return;
    }
    supabase
      .from("profiles")
      .select("*")
      .eq("id", usuario.id)
      .single()
      .then(({ data }) => setPerfil(data));
  }, [usuario]);

  // Cadastro com nome, telefone, senha e confirmação por e-mail
  async function cadastrar({ nome, telefone, email, senha }) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password: senha,
      options: {
        data: { nome, telefone }, // vai para raw_user_meta_data -> trigger cria o profile
        emailRedirectTo: `${window.location.origin}/confirmado`,
      },
    });
    return { data, error };
  }

  async function entrar({ email, senha }) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password: senha });
    return { data, error };
  }

  async function sair() {
    await supabase.auth.signOut();
  }

  async function recuperarSenha(email) {
    return supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/redefinir-senha`,
    });
  }

  return (
    <AuthContext.Provider
      value={{ usuario, perfil, carregando, cadastrar, entrar, sair, recuperarSenha }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth precisa estar dentro de <AuthProvider>");
  return ctx;
}
