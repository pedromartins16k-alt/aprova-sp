import { Routes, Route } from "react-router-dom";
import Inicio from "./pages/Inicio";
import Entrar from "./pages/Entrar";
import Cadastro from "./pages/Cadastro";
import RecuperarSenha from "./pages/RecuperarSenha";
import Painel from "./pages/Painel";
import Resumos from "./pages/Resumos";
import Flashcards from "./pages/Flashcards";
import Simulados from "./pages/Simulados";
import Perfil from "./pages/Perfil";
import RotaProtegida from "./components/RotaProtegida";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Inicio />} />
      <Route path="/entrar" element={<Entrar />} />
      <Route path="/cadastro" element={<Cadastro />} />
      <Route path="/recuperar-senha" element={<RecuperarSenha />} />

      <Route path="/painel" element={<RotaProtegida><Painel /></RotaProtegida>} />
      <Route path="/resumos" element={<RotaProtegida><Resumos /></RotaProtegida>} />
      <Route path="/flashcards" element={<RotaProtegida><Flashcards /></RotaProtegida>} />
      <Route path="/simulados" element={<RotaProtegida><Simulados /></RotaProtegida>} />
      <Route path="/perfil" element={<RotaProtegida><Perfil /></RotaProtegida>} />
    </Routes>
  );
}
